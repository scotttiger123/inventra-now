// config/config.js
export default {
  apiBaseUrl: 'https://lv.inventra.pk/api', // Base URL for API requests
  themeColor: '#000', // Define other configurations as needed
  lightTextColor : '#888' // Lighter color for the text
};
